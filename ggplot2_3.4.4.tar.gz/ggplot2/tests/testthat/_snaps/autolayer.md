# autolayers default error looks correct

    No autolayer method avialable for <character> objects

