# summarise_*() throws appropriate errors

    `p` must be a <ggplot_built> object, not the number 10.

---

    `p` must be a <ggplot_built> object, not the string "A".

---

    `p` must be a <ggplot_built> object, not `TRUE`.

